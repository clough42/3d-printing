Itty Bitty Double Flex Extruder
-------------------------------
Alpha Test 0.1.0 release

This is an alpha test release.  It has not been significantlty tested.  Use at your own risk.

The Itty Bitty Flex Extruder is a compact, two-material extruder designed to accomodate
E3D-v6 hot ends and flexible filament.

-------------------------------
Clough42, LLC
clough42llc@gmail.com
http://clough42.com